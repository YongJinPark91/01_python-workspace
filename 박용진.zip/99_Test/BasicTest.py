# 1. 이름과 나이 정보가 기록된 sample02.txt 파일이 있다고 가정합니다.

# 2. 파일을 읽기 모드로 열고 데이터를 읽습니다.
with open('01_python-workspace/99_Test/sample02.txt', 'r') as file:
    data = file.readlines()

# 3. 결과를 저장할 파일 객체를 생성합니다.
myfile2 = open('01_python-workspace/99_Test/result02.txt', 'w')

# 4. 반복문을 사용하여 데이터를 분리합니다.
for line in data:
    # 줄바꿈 문자 제거하고 쉼표로 데이터를 분리합니다.
    name, age = line.strip().split(',')

    # 5. 2번째 열 정보가 나이를 의미하므로, 19세 이상인지 판단하여 '성인' 또는 '미성년'으로 분기 처리합니다.
    if int(age) >= 19:
        status = '성인'
    else:
        status = '미성년'

    # 6. 결과 내용을 슬래시(/)를 사용하여 문자열을 결합합니다.
    result = name + '/' + status

    # 7. 최종 결과를 myfile2 객체에 저장합니다.
    myfile2.write(result + '\n')

# myfile2 객체를 닫습니다.
myfile2.close()
